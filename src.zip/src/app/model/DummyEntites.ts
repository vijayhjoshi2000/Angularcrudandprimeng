export class DummyEntity
    {
        public IdentityCol:number;

        public  Name:string;

        public  Age:number;
        public  OptionalCol:string;

        constructor(id:number, name:string, age:number, optional:string)
        {
            this.IdentityCol = id;
            this.Age = age;
            this.Name = name;
            this.OptionalCol = optional;
        }
    }