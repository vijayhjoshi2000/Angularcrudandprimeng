import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditdummyComponent } from './editdummy.component';

describe('EditdummyComponent', () => {
  let component: EditdummyComponent;
  let fixture: ComponentFixture<EditdummyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditdummyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditdummyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
