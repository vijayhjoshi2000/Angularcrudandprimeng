import { Component, OnInit } from '@angular/core';
import { DummyAPIService } from '../services/DummyService.service';
import { DummyEntity } from '../model/DummyEntites';

import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";

@Component({
  selector: 'app-editdummy',
  templateUrl: './editdummy.component.html',
  styleUrls: ['./editdummy.component.css']
})
export class EditdummyComponent implements OnInit {

  dummy:DummyEntity;
  editForm: FormGroup;

  constructor(private formBuilder: FormBuilder,private router: Router, private service:DummyAPIService) { }

  ngOnInit() {
    this.fillForm();
    var id= window.localStorage.getItem("id");
    this.service.getDummy(parseInt(id)).subscribe(res=>this.setValue(res)
      );
  }

  onSubmit(){    
    this.dummy.Name = this.editForm.value.Name;
    this.dummy.Age = this.editForm.value.Age;
    this.dummy.OptionalCol = this.editForm.value.OptionalCol;    
    this.service.updateDummy(this.dummy).subscribe(r=> this.router.navigate(['View']));
  }

  private fillForm(){
    this.editForm = this.formBuilder.group({
      Name: ['', Validators.required], 
      Age: ['', Validators.required], 
      OptionalCol: ['', Validators.required],
      IdentityCol: ['', Validators.required],
    });
  }

  private setValue(d:any){    
    this.dummy = new DummyEntity(d.IdentityCol, d.Name, d.Age, d.OptionalCol); 
    this.editForm.setValue(this.dummy);
  }

}
