import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewdummyComponent } from './viewdummy.component';

describe('ViewdummyComponent', () => {
  let component: ViewdummyComponent;
  let fixture: ComponentFixture<ViewdummyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewdummyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewdummyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
