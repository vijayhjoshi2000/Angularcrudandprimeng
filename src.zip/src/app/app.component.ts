import { Component} from '@angular/core';
import { DummyAPIService } from './services/DummyService.service';
import { DummyEntity } from './model/DummyEntites';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'dummyAngular';

  
}
