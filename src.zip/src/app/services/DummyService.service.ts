import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DummyEntity } from '../model/DummyEntites';
import { Observable } from 'rxjs';
 
@Injectable({
  providedIn: 'root'
})
export class DummyAPIService {
 
  constructor(private http: HttpClient) { }
 
  public getDummies(): Observable<DummyEntity[]> 
  {
    const url = 'http://localhost:85/api/dummy';
 
    return this.http.get<DummyEntity[]>(url);
  }

  public getDummy(id:number): Observable<DummyEntity> 
  {
    const url = 'http://localhost:85/api/dummy/' + id;
 
    return this.http.get<DummyEntity>(url);
  }

  public addDummy(dummy:DummyEntity): Observable<object> 
  {
    const url = 'http://localhost:85/api/dummy/';
 
    return this.http.post(url, dummy);
  }

  public updateDummy(dummy:DummyEntity): Observable<object> 
  {
    const url = 'http://localhost:85/api/dummy/';
 
    return this.http.put(url, dummy);
  }

  public deleteDummy(id:number): Observable<object> 
  {
    const url = 'http://localhost:85/api/dummy/'+ id;
 
    return this.http.delete(url);
  }
}