import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdddummyComponent } from './adddummy/adddummy.component';
import { EditdummyComponent } from './editdummy/editdummy.component';
import { ViewdummyComponent } from './viewdummy/viewdummy.component';
import { ViewdummygridComponent } from './viewdummygrid/viewdummygrid.component';


const routes: Routes = [
  { path: '', redirectTo: 'View', pathMatch: 'full' },  
  { path: 'Add', component: AdddummyComponent },  
  { path: 'Edit', component: EditdummyComponent },
  { path: 'View', component: ViewdummyComponent },
  { path: 'Viewng', component: ViewdummygridComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
