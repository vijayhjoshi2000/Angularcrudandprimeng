import { Component, OnInit } from '@angular/core';
import { DummyAPIService } from '../services/DummyService.service';
import { DummyEntity } from '../model/DummyEntites';
import {FormBuilder, FormGroup, Validators, ReactiveFormsModule} from "@angular/forms";
import {Router} from "@angular/router";

@Component({
  selector: 'app-adddummy',
  templateUrl: './adddummy.component.html',
  styleUrls: ['./adddummy.component.css']
})
export class AdddummyComponent implements OnInit {


  
  addForm: FormGroup;
  constructor(private formBuilder: FormBuilder,private router: Router, private service:DummyAPIService){}

  ngOnInit()
  {   
    this.addForm = this.formBuilder.group({
      id: [],
      name: ['', [Validators.required]],
      age: ['', Validators.required],
      optional: ['']
    });
  }

  onSubmit(){
    
    var dummy  = new DummyEntity(0, this.addForm.value.name, this.addForm.value.age, this.addForm.value.optional);
    this.service.addDummy(dummy).subscribe(
      res=> { this.router.navigate(['View']) }
    );
    
  }

}
