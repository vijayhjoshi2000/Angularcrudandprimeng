import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdddummyComponent } from './adddummy.component';

describe('AdddummyComponent', () => {
  let component: AdddummyComponent;
  let fixture: ComponentFixture<AdddummyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdddummyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdddummyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
