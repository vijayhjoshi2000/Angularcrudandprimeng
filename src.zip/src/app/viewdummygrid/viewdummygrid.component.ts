import { Component, OnInit } from '@angular/core';
import { DummyEntity } from '../model/DummyEntites';
import { DummyAPIService } from '../services/DummyService.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewdummygrid',
  templateUrl: './viewdummygrid.component.html',
  styleUrls: ['./viewdummygrid.component.css']
})
export class ViewdummygridComponent implements OnInit {

  dummies = new Array<DummyEntity>();

  constructor(private service:DummyAPIService, private router: Router){}

  ngOnInit()
  {
    
    this.getDummies();
  }

  delete(id:number)
  {
    this.service.deleteDummy(id).subscribe(r=>this.getDummies());    
  }

  edit(dummy:DummyEntity){
    window.localStorage.setItem("id", dummy.IdentityCol.toString());
    this.router.navigate(['Edit']);
  }

  private getDummies(){
    this.service.getDummies().subscribe(
      res => {
      debugger  
        this.dummies = res.map(
          dummy => {
            return new DummyEntity(
              dummy.IdentityCol, 
              dummy.Name, 
              dummy.Age, 
              dummy.OptionalCol);
          });
      });
  }

}
