import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewdummygridComponent } from './viewdummygrid.component';

describe('ViewdummygridComponent', () => {
  let component: ViewdummygridComponent;
  let fixture: ComponentFixture<ViewdummygridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewdummygridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewdummygridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
